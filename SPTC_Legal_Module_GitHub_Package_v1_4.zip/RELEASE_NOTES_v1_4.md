# Release Notes – v1.4

This release provides the stable public reference version of the SPTC Legal Module.

## Highlights
- Opt-in, but binding once jointly invoked for a dispute
- No precedent; binary decisions; no permanent decision body
- Replacement only via multi-stage procedure (initiative → test → 2/3 vote)
- CC BY-SA 4.0 open license (no fees; derivatives must remain open)

## Included Documents
See /docs for the canonical DOCX files (DE/EN).
