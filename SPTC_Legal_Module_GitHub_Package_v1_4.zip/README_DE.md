# SPTC Rechtsmodul v1.4

Dieses Repository enthält das SPTC-Rechtsmodul v1.4 und begleitende Unterlagen.

Das SPTC-Rechtsmodul ist ein **freiwilliges, nicht-hoheitliches Ordnungsinstrument** zur Klärung **seltener, systemkritischer Streitfälle**
in regelbasierten Infrastrukturen. Es ist **kein** Gericht, **kein** Schiedsverfahren und **kein** Governance-Tool.

## Inhalt
- Rechtsmodul v1.4 (DE/EN)
- Whitepaper (DE/EN)
- Muster-Referenzklauseln (DE/EN)
- Kurz-FAQ für Anwälte und Prüfer
- Technische Leitplanken (was Code darf und nicht darf)

## Was es ist
- ein Mechanismus zur Machtbegrenzung im Ausnahmefall
- Opt-in, aber nach gemeinsamer Anrufung bindend für den Streitfall
- binär, ohne Präzedenz

## Was es nicht ist
- kein Ersatz staatlicher Gerichte
- kein dauerhaftes Gremium
- kein Lizenz- oder Gebührenmodell

## Lizenz
Creative Commons Attribution–ShareAlike 4.0 International (CC BY-SA 4.0).
Die Lizenz ist **keine Gebühr** und **keine Genehmigung**, sondern eine strukturelle Ordnungsschranke.
