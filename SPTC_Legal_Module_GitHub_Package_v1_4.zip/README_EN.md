# SPTC Legal Module v1.4

This repository contains the SPTC Legal Module v1.4 and supporting documents.

The SPTC Legal Module is a **voluntary, non-sovereign ordering instrument** for resolving **rare, system‑critical disputes**
in rule‑based infrastructures. It is **not** a court, **not** arbitration, and **not** a governance platform.

## Contents
- Legal Module v1.4 (DE/EN)
- Whitepaper (DE/EN)
- Reference clauses (DE/EN)
- Short FAQ for lawyers and auditors
- Technical guardrails (what code may and may not do)

## What this is
- a power‑limiting mechanism for exceptional situations
- opt‑in, but binding once jointly invoked for a specific dispute
- binary decisions, no precedent

## What this is not
- not a replacement for state courts
- not a permanent decision body
- not a fee/licensing business model

## License
Creative Commons Attribution–ShareAlike 4.0 International (CC BY-SA 4.0).
The license is **not a fee** and **not a permission mechanism**, but a structural safeguard for order.
