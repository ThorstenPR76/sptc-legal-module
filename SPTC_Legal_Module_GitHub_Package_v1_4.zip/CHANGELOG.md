# Changelog

## v1.4
- Added formal replacement procedure: initiative (3–5%), test phase (100 days, non-binding), final vote (10 days, ≥2/3 active approvals).
- Clarified prospective-only effect; ongoing/initiated disputes remain unaffected.
- Added explicit CC BY-SA 4.0 license header (DE/EN documents).

## v1.3
- Removed ambiguous wording around "deactivation"; clarified opt-in and binding effect.

## v1.2 and earlier
- Internal iterations and drafting.
