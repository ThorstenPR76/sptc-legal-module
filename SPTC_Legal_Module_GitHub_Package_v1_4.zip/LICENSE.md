# License

This work is licensed under **Creative Commons Attribution–ShareAlike 4.0 International (CC BY-SA 4.0)**.

- You may use, share, and adapt the material.
- If you adapt it, you must distribute your contributions under the **same license**.
- This license is **not a fee** and **not a permission mechanism**; it is a structural safeguard for order.

Full license text: https://creativecommons.org/licenses/by-sa/4.0/
